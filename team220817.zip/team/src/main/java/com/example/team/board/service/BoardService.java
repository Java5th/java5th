package com.example.team.board.service;

import com.example.team.board.repository.BoardMapper;
import com.example.team.user.dto.SearchDto;
import com.example.team.user.entity.UserInfoEntity;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardMapper boardMapper;

    public Page<UserInfoEntity> getUserList(int pageNum, SearchDto searchDto) throws Exception{
        PageHelper.startPage(pageNum, 10);
        return boardMapper.findUser(searchDto);
    }
}
