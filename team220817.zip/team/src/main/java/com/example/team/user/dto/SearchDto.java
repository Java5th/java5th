package com.example.team.user.dto;

import lombok.Data;

@Data
public class SearchDto {
    private String keyword;
    private String search;
}
