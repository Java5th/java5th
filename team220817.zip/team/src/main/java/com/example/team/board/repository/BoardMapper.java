package com.example.team.board.repository;

import com.example.team.user.dto.SearchDto;
import com.example.team.user.entity.UserInfoEntity;
import com.github.pagehelper.Page;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {
    public Page<UserInfoEntity> findUser(SearchDto searchDto);
}
