package com.example.team.board.controller;

import com.example.team.board.service.BoardService;
import com.example.team.user.dto.SearchDto;
import com.example.team.user.entity.UserInfoEntity;
import com.github.pagehelper.PageInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
@RequestMapping("/board")
public class BoardController {
    private final BoardService boardService;

    @GetMapping("/list")
    public String page(@ModelAttribute SearchDto searchDto, @RequestParam(required = false, defaultValue = "1") int pageNum, Model model) throws Exception {
        PageInfo<UserInfoEntity> pageInfo = new PageInfo<>(boardService.getUserList(pageNum, searchDto), 10);
        model.addAttribute("users",pageInfo);
        model.addAttribute("search",searchDto);
        return "paging";
    }
}
