package com.example.team.board.entity;

import lombok.Data;

@Data
public class BoardEntity {

}
