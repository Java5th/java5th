package common;

public class Emp {
   int employee_id;
   String name;
   int salary;
   
   
}
