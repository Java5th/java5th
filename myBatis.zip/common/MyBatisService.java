package common;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class MyBatisService {
	private MyBatisDao dao = new MyBatisDao();
	
//	public List<Emp> selectIdPw(){
//		SqlSession ses = SqlSessionTemplate.getSession();
//		List<Emp> list = dao.selectIdPw(ses);
//		return list;
//	}
	
	public List<Emp> selectList(){
		SqlSession ses = SqlSessionTemplate.getSession();
		List<Emp> list = dao.selectList(ses);
		return list;
	}
	
	public int deleteInfo(int select) {
		SqlSession ses = SqlSessionTemplate.getSession();
		int nn = dao.deleteInfo(ses, select);
		if(nn>0) {
			ses.commit();
		}else {
			ses.rollback();
		}
		ses.close();
		return nn;
	}
	
	public Emp findInfo(int emp_id) {
		SqlSession ses = SqlSessionTemplate.getSession();
		Emp emp= dao.findInfo(ses, emp_id);
//		return new Emp(emp.emp_name,emp.emp_salary);
//		return new Emp(emp.emp_name);
		return emp;
	}
	
	public int insertEx(Emp emp) {
		SqlSession ses = SqlSessionTemplate.getSession();
		
		int nn = dao.insertEx(ses,emp);
		if(nn > 0) {
			ses.commit();
		}else {
			ses.rollback();
		}
		ses.close();
		return nn;
	}
	
	public String selectName(int nn) {
		SqlSession ses = SqlSessionTemplate.getSession();
		String ss= dao.selectName(ses,nn);
		return ss;
	}
	
	public int insertEx0621() {
		SqlSession ses = SqlSessionTemplate.getSession();
		int nn = dao.insertEx0621(ses);
		if(nn > 0) {
			ses.commit();
		}else {
			ses.rollback();
		}
		ses.close();
		return nn;
	}
}
