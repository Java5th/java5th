package common;

public class Emp {
	int emp_id;
	String emp_name;
	int emp_salary;
//	String id;
//	String pw;

	
	@Override
	public String toString() {
		return "["+emp_id+","+emp_name+","+emp_salary+"]";
	}

	

}
