package common;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

public class MyBatisDao {

	public Emp findInfo(SqlSession ses, int emp_id) {
		Emp emp = ses.selectOne("mybatis.findInfo",emp_id);
		return emp;
	}
	
	public int deleteInfo(SqlSession ses, int emp_id) {
		int nn = ses.delete("mybatis.deleteInfo",emp_id);
		return nn;
	}
	
//	public List<Emp> selectIdPw(SqlSession ses){
//		List<Emp> idpw=ses.selectList("mybatis.selectIdPw");
//		return idpw;
//	}
	
	public List<Emp> selectList(SqlSession ses){
		List<Emp> ss=ses.selectList("mybatis.selectList");
		return ss;
	}
	public int insertEx(SqlSession ses,Emp emp) {
		int nn=ses.insert("mybatis.insertEx", emp);
		return nn;
	}
	
	public int insertEx0621(SqlSession ses) {
		int nn = ses.insert("mybatis.insertEx0621");
		return nn;
	}

	public String selectName(SqlSession ses, int nn) {
		String ss = ses.selectOne("mybatis.selectName", nn);
		return ss;
	}
}
