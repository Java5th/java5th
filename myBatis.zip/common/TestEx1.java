package common;

public class TestEx1 {

	public static void main(String[] args) {
		MyBatisService ms = new MyBatisService();

//		for(Emp idpw:ms.selectIdPw()) {
//			System.out.println(idpw);
//		}
		
//		for(Emp ee:ms.selectList()) {
//			System.out.println(ee);
//		}
		
//		Emp emp = new Emp();
//		emp.emp_id = 1;
//		emp.emp_name = "�褷��";
//		emp.emp_salary= 300;
//		int nn = ms.insertEx(emp);
//		System.out.println(nn);
		
//		String dd=ms.selectName(200);
//		System.out.println(dd);
		
//		int n = ms.insertEx0621();
//		System.out.println(n+"�� �Է�!");
		
//		int a = ms.deleteInfo(1);
//		System.out.println(a);
//		int a = ms.deleteInfo(201);
//		System.out.println(a);
//
		
		Emp e = ms.findInfo(103);
		System.out.println(e.emp_name+" "+e.emp_salary);
//		System.out.println(e.emp_name);
//		System.out.println(e);
		
		
	}

}
